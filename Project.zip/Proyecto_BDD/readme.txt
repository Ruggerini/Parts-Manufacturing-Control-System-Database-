To install the database, you will need MySQL, then, you go to the terminal or any DBMS like HeidiSQL and create the database. You can either import the sql file into the DBMS or create it manually with the code that's in just_in_case.txt (inside the database folder).

Remember to update your database info in the main.py file. Good luck!