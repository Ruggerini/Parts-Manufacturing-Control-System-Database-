-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               11.3.0-MariaDB - mariadb.org binary distribution
-- Server OS:                    Win64
-- HeidiSQL Version:             12.3.0.6589
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- Dumping data for table proyecto2.componentes: ~21 rows (approximately)
INSERT IGNORE INTO `componentes` (`id_Componentes`, `Nombre_Componente`, `Vehiculo_idVehiculo`) VALUES
	(1, 'Motor de gasolina', 1),
	(2, 'frenos', 1),
	(3, 'sistema de sonido', 1),
	(4, 'Motor de diesel', 2),
	(5, 'frenos', 2),
	(6, 'sistema de sonido', 2),
	(7, 'Motor de electrico', 3),
	(8, 'frenos', 3),
	(9, 'sistema de sonido', 3),
	(10, 'Motor de GLP', 4),
	(11, 'frenos', 4),
	(12, 'sistema de sonido', 4),
	(13, 'Motor de GNC', 5),
	(14, 'frenos', 5),
	(15, 'sistema de sonido', 5),
	(19, 'Motor de encendido por compresión', 7),
	(20, 'frenos', 7),
	(21, 'sistema de sonido', 7),
	(22, 'Motor monocilíndrico', 8),
	(23, 'frenos', 8),
	(24, 'Sistema de sonido', 8);

-- Dumping data for table proyecto2.marca: ~4 rows (approximately)
INSERT IGNORE INTO `marca` (`idMarca`, `Nombre_Marca`) VALUES
	(1, 'Nissan'),
	(2, 'Toyota'),
	(3, 'Honda'),
	(4, 'Ferrari');

-- Dumping data for table proyecto2.modelo: ~8 rows (approximately)
INSERT IGNORE INTO `modelo` (`idModelo`, `Nombre_Modelo`, `Marca_idMarca`) VALUES
	(1, 'X-Trail', 1),
	(2, 'Qashqai', 1),
	(3, 'Landcruiser', 2),
	(4, 'Corolla Cross', 2),
	(5, 'CR-VV', 3),
	(7, 'Roma', 4),
	(8, 'SF90', 4),
	(9, 'JHJHJH', 4);

-- Dumping data for table proyecto2.piezas: ~18 rows (approximately)
INSERT IGNORE INTO `piezas` (`id_piezas`, `nombre_pieza`, `Estado`, `Peso`, `Medidas`, `id_Componente`) VALUES
	(2, 'culata', 'Nuevo', 0, '10cmx10cm', 1),
	(3, 'Pastillas de freno', 'Reacondicionado', 0, '10cmx10cm', 2),
	(4, 'Zapatas de freno', 'Reacondicionado', 0, '10cmx10cm', 2),
	(5, ' Fuente', 'Nuevo', 0, '10cmx10cm', 3),
	(6, ' Altavoces', 'Nuevo', 0, '10cmx10cm', 3),
	(7, ' Pistones2', 'Nuevo', 0, '10cmx10cm', 4),
	(8, ' culata2', 'Reacondicionado', 0, '10cmx10cm', 4),
	(9, ' Pastilla de freno2', 'Nuevo', 0, '10cmx10cm', 5),
	(10, ' Zapatos de freno2', 'Nuevo', 0, '10cmx10cm', 5),
	(12, ' Altavoces2', 'Reacondicionado', 0, '10cmx10cm', 6),
	(13, ' Pistones3', 'Reacondicionado', 0, '10cmx10cm', 7),
	(14, ' culata3', 'Reacondicionado', 0, '10cmx10cm', 7),
	(15, ' Pastillas de freno3', 'Nuevo', 0, '10cmx10cm', 8),
	(16, ' Zapatos de freno3', 'Nuevo', 0, '10cmx10cm', 8),
	(17, ' Altavoces3', 'Reacondicionado', 0, '10cmx10cm', 9),
	(11, ' Fuente2', 'Reacondicionado', 0, '10cmx10cm', 6),
	(1, 'Pistones', 'Nuevo', 10, '30cmx30cm', 1);

-- Dumping data for table proyecto2.vehiculo: ~7 rows (approximately)
INSERT IGNORE INTO `vehiculo` (`idVehiculo`, `Tipo_Vehiculo`, `Modelo_idModelo`, `año`) VALUES
	(1, 'Carro', 1, '2023'),
	(2, 'Carro', 2, '2020'),
	(3, 'Carro', 3, '2019'),
	(4, 'Carro', 4, '2015'),
	(5, 'Carro', 5, '2019'),
	(7, 'Carro', 7, '2010'),
	(8, 'Carro', 8, '2021');

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
